extends Node3D

const SPEED : float = 15.0
var direction : Vector3 = Vector3.FORWARD

func _process(delta: float) -> void:
	# Move the projectile forward along its assigned direction path
	global_translate(direction * SPEED * delta)
