extends Node3D

@export var bullet_prefab : PackedScene
@onready var native_pool = $UniversalNativePool

# Benchmark Parameters
const BULLETS_PER_FRAME : int = 15  # Shoots 15 bullets EVERY single frame!
const BULLET_LIFETIME : float = 3.0 # Automatically recycles after 3 seconds
var radial_angle : float = 0.0
var total_spawned_count : int = 0

# UI Overlay Elements
var fps_label : Label

func _ready() -> void:
	# 1. Register our bullet scene inside our Rust dictionary pool.
	# We warm up 2,500 units upfront to handle the rapid radial stream!
	native_pool.register_scene("bullet", bullet_prefab, 2500)
	
	# 2. Build the visual FPS Benchmark text overlay dynamically
	setup_fps_overlay()

func _process(delta: float) -> void:
	# --- RADIAL SPRAY ENGINE ---
	# Spawn multiple projectiles spread evenly across a circle this frame
	for i in range(BULLETS_PER_FRAME):
		# Calculate the 360-degree radial path mapping
		radial_angle += (2.0 * PI) / 64.0
		var dir_vector = Vector3(cos(radial_angle), 0, sin(radial_angle)).normalized()
		
		# Spawn location: center origin (0, 0, 0) lifted slightly up to clear your CSG ground plane
		var spawn_origin = Vector3(0.0, 1.5, 0.0)
		
		# Pull the bullet instantly from our bare-metal Rust memory vector array
		var bullet_instance = native_pool.spawn("bullet", spawn_origin, Vector3.ZERO)
		
		if is_instance_valid(bullet_instance):
			# Inject the travel path direction directly into the bullet script
			bullet_instance.direction = dir_vector
			total_spawned_count += 1
			
			# Trigger an optimized delayed asynchronous recycling hook
			recycle_after_time(bullet_instance, BULLET_LIFETIME)
			
	# Update our tracking display numbers
	fps_label.text = "FPS: %d\nActive Visual Projectiles: %d" % [Engine.get_frames_per_second(), total_spawned_count]

func recycle_after_time(entity: Node3D, duration: float) -> void:
	await get_tree().create_timer(duration).timeout
	if is_instance_valid(entity):
		# Cleanly return the object right back into the unmanaged vector cache channel
		native_pool.despawn("bullet", entity)
		total_spawned_count -= 1

func setup_fps_overlay() -> void:
	# Instantiates a clean, crisp screen canvas overlay for benchmark readouts
	var canvas_layer = CanvasLayer.new()
	add_child(canvas_layer)
	
	fps_label = Label.new()
	fps_label.position = Vector2(20, 20)
	# Apply a clean font scale so it jumps out nicely over your 3D view grid
	fps_label.add_theme_font_size_override("font_size", 24)
	canvas_layer.add_child(fps_label)
