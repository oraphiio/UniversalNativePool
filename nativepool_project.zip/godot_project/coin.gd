# Save as: coin.gd (Attach to root of coin.tscn)
extends Node3D

func _ready() -> void:
	# Triggers the exact microsecond the Harvest Hook grabs the placement coordinates
	print("🟡 [COIN LIFECYCLE]: Editor placeholder successfully harvested and pooled! Node Name: ", name)
