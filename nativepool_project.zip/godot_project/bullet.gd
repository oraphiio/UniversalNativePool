# Save as: bullet.gd (Attach to root of bullet.tscn)
extends Node3D

const SPEED : float = 15.0
var direction : Vector3 = Vector3.FORWARD

func _ready() -> void:
	# Triggers when Rust creates the entity inside memory or instantiates it on overflow
	print("🟢 [BULLET LIFECYCLE]: Instantiated in engine memory. Node Name: ", name)

func _process(delta: float) -> void:
	# Automatically handled by Rust set_process(true/false) toggle states
	global_translate(direction * SPEED * delta)
	
	# Automatically self-despawn if it goes too far so we don't leak memory eternally
	#if global_position.length() > 60.0:
	#	var pool = get_node_or_null("/root/Node3D/UniversalNativePool") # Update path if your root is named differently
		#if pool:
		#	pool.despawn("bullets", self)
