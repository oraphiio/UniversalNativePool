extends Node3D
## RadialSpawner.gd v2 — continuous spray + burst harness for UniversalNativePool (gdext 0.5.5).
##
## WHAT TO WATCH (the actual allocation test):
##   * First seconds of spray: pool drains dormant stock. If concurrent live bullets exceed
##     stock, you see "chunk allocation block (+32)" warnings ONCE per exhaustion.
##   * After that, warnings must STOP completely: expired bullets are recycled, not re-created.
##   * [Spawner] stats line: `active(pool)` plateaus around fire_rate * bullet_lifespan while
##     `spawned` and `recycled` keep climbing = zero new allocations, pure reuse.
##   * Press P anytime for the Dormant/Active readout from the Rust side.
##
## CONTROLS:
##   hold SPACE or LMB ....... manual spray (adds on top of auto_spray)
##   1 / 2 / 3 ............... burst waves 200 / 500 / 600 (old stress test)
##   D ....................... despawn everything live right now
##   P ....................... Rust pool diagnostics
##   R ....................... reset coins channel (re-deploy the 8 harvested layouts)

@export var pool_path: NodePath = ^"../UniversalNativePool"

# --- Continuous spray ---
@export var auto_spray: bool = true            # start spraying immediately on Play
@export var fire_rate: float = 120.0           # bullets per second
@export var bullet_speed: float = 18.0
@export var bullet_lifespan: float = 2.5       # seconds in flight, then recycled
@export var upward_bias: float = 0.45          # 0 = flat radial ring, 1 = fountain straight up
@export var simulate_gravity: bool = true
@export var gravity: float = 9.8
@export var kill_height: float = -0.45         # recycle early if bullet falls below plane top
@export var align_to_velocity: bool = true     # point bullet mesh along flight direction
@export var stats_interval: float = 2.0        # seconds between stats prints (0 = off)

# --- Burst waves (manual) ---
@export var waves: Array[int] = [200, 500, 600]

var pool: Node = null
var _live: Array[Dictionary] = []      # {node: Node3D, vel: Vector3, ttl: float}
var _spawn_acc: float = 0.0
var _stats_acc: float = 0.0
var _total_spawned: int = 0
var _total_recycled: int = 0
var _held: bool = false


func _ready() -> void:
	pool = get_node_or_null(pool_path)
	if pool == null:
		push_error("Spawner: UniversalNativePool not found at %s" % pool_path)
		return
	print("[Spawner] linked. bullets active: %d (dormant stock ready), coins active: %d (harvested)" % [
		pool.get_active_count("bullets"), pool.get_active_count("coins")])
	print("[Spawner] steady-state target ≈ %d concurrent bullets (fire_rate × lifespan)" % [
		int(fire_rate * bullet_lifespan)])


func _unhandled_input(event: InputEvent) -> void:
	if pool == null:
		return
	if event is InputEventKey:
		match event.keycode:
			KEY_SPACE:
				_held = event.pressed
				return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_held = event.pressed
		return
	if not (event is InputEventKey) or not event.pressed:
		return
	match event.keycode:
		KEY_1, KEY_2, KEY_3:
			var idx: int = event.keycode - KEY_1
			if idx < waves.size():
				_burst(waves[idx])
		KEY_D:
			_despawn_all()
		KEY_P:
			pool.trigger_pool_diagnostic_print = true
		KEY_R:
			pool.reset_channel("coins")
			print("[Spawner] coins channel reset to harvested layout")


func _process(delta: float) -> void:
	if pool == null:
		return

	# 1) Emit: fractional accumulator = frame-rate independent fire rate
	if auto_spray or _held:
		_spawn_acc += fire_rate * delta
		while _spawn_acc >= 1.0:
			_spawn_acc -= 1.0
			_spawn_bullet()

	# 2) Integrate flight + recycle expired / fallen bullets (reverse iterate = safe remove)
	for i in range(_live.size() - 1, -1, -1):
		var e: Dictionary = _live[i]
		var n: Node3D = e.node
		if not is_instance_valid(n):
			_live.remove_at(i)
			continue
		var vel: Vector3 = e.vel
		if simulate_gravity:
			vel.y -= gravity * delta
			e.vel = vel
		n.global_position += vel * delta
		e.ttl -= delta
		if e.ttl <= 0.0 or n.global_position.y < kill_height:
			pool.despawn("bullets", n)
			_total_recycled += 1
			_live.remove_at(i)

	# 3) Stats heartbeat
	if stats_interval > 0.0:
		_stats_acc += delta
		if _stats_acc >= stats_interval:
			_stats_acc = 0.0
			print("[Spawner] live: %d | active(pool): %d | spawned: %d | recycled: %d  <- plateau + no chunk warns = reuse OK" % [
				_live.size(), pool.get_active_count("bullets"), _total_spawned, _total_recycled])


func _spawn_bullet() -> void:
	var node = pool.spawn("bullets", global_position)
	if node == null:
		push_warning("[Spawner] pool.spawn('bullets') returned null")
		return
	var n3d: Node3D = node as Node3D
	if n3d == null:
		pool.despawn("bullets", node)
		return

	var dir: Vector3 = _random_spray_dir()
	var speed: float = bullet_speed * randf_range(0.85, 1.15)

	if align_to_velocity and absf(dir.y) < 0.99:
		n3d.global_transform = n3d.global_transform.looking_at(
			n3d.global_position + dir, Vector3.UP)

	_live.append({"node": n3d, "vel": dir * speed, "ttl": bullet_lifespan})
	_total_spawned += 1


func _random_spray_dir() -> Vector3:
	var a: float = randf() * TAU
	var horizontal := Vector3(cos(a), 0.0, sin(a))
	return (horizontal + Vector3.UP * upward_bias * randf_range(0.6, 1.4)).normalized()


func _burst(count: int) -> void:
	var t: int = Time.get_ticks_msec()
	for i in count:
		_spawn_bullet()
	print("[Spawner] burst %d bullets in %d ms | active: %d" % [
		count, Time.get_ticks_msec() - t, pool.get_active_count("bullets")])


func _despawn_all() -> void:
	for e in _live:
		if is_instance_valid(e.node):
			pool.despawn("bullets", e.node)
			_total_recycled += 1
	_live.clear()
	print("[Spawner] all live bullets recycled | active: %d" % pool.get_active_count("bullets"))
