# Save as: master_pool_test_suite.gd
# Attach to: MasterPoolTestSuite Node3D under the level root node.
extends Node3D

@onready var pool = get_node("../UniversalNativePool")
@onready var floor_plane = get_node("../CSGMesh3D")

var current_step: int = 0
var test_timer: float = 0.0
var active_bullet_nodes: Array[Node] = []
var bullet_directions: Array[Vector3] = []

func _ready() -> void:
	print("============ 🚀 VISUAL POOL ENGINE MATRIX OPERATIONAL ============")
	
	# 1. POSITION THE SPAWNER OVER THE PLANE
	# Automatically centers this tester node on your CSGMesh3D floor plane and lifts it up 1.5 units
	if floor_plane:
		global_position = floor_plane.global_position + Vector3(0.0, 1.5, 0.0)
		print("[SPAWNER SET] Positioned spawner directly over center floor plane: ", global_position)
	
	print("[SYSTEM STATUS] Awaiting 2 seconds for visual configurations...")

func _process(delta: float) -> void:
	test_timer += delta
	
	# --- RUNTIME PROJECTILE MOVE ENGINE ---
	# Continuously updates spawned bullet positions so they slice through the air visually!
	for i in range(active_bullet_nodes.size()):
		if is_instance_valid(active_bullet_nodes[i]):
			var dir = bullet_directions[i]
			active_bullet_nodes[i].global_translate(dir * 18.0 * delta)

	# --- STEPWISE VISUAL EXPERIMENT TIMERS ---
	if current_step == 0 and test_timer >= 2.0:
		current_step = 1
		execute_test_step_1_keep_coins_visible()
		
	elif current_step == 1 and test_timer >= 5.0:
		current_step = 2
		execute_test_step_2_radial_bullet_burst()

# 🛠️ STEP 1: RESTORE AND SHOW COINS RIGHT AWAY
func execute_test_step_1_keep_coins_visible() -> void:
	print("\n--- 🟢 VISUAL STEP 1: DEPLOYING DESIGNER PLACEMENTS ---")
	
	# Force the Rust core to pull the 8 coins from the harvest registry cache immediately
	pool.reset_channel("coins")
	
	var active_coins = pool.get_active_count("coins")
	print("[DIAGNOSTIC] Hand-placed coins deployed onto map layout: ", active_coins)
	print("👉 VIEWPORT LOOKUP: Your original 8 coins are now snapped live onto their positions!")
	pool.trigger_pool_diagnostic_print = true

# 🛠️ STEP 2: SHOOT BULLETS RADIALLY IN THE MIDDLE OF THE PLANE
func execute_test_step_2_radial_bullet_burst() -> void:
	print("\n--- 🟢 VISUAL STEP 2: HIGH-VOLUME RADIAL SPRAY ---")
	print("[ACTION] Spawning 550 bullets from center coordinates...")
	
	# Fires 550 projectiles outwards in a circular wheel format directly from the centered spawner coordinates
	for i in range(550):
		var bullet = pool.spawn("bullets", global_position)
		if bullet:
			active_bullet_nodes.append(bullet)
			
			var angle = i * (PI * 2.0 / 64.0)
			var flight_direction = Vector3(cos(angle), 0.0, sin(angle)).normalized()
			bullet_directions.append(flight_direction)
			
	print("[DIAGNOSTIC] Total active bullets shooting wild across floor plane: ", pool.get_active_count("bullets"))
	print("👉 VIEWPORT LOOKUP: Watch the machine gun spray fly outwards over your floor grid mesh!")
	pool.trigger_pool_diagnostic_print = true
	print("\n============ 🏆 VISUAL RUN STABLE. GAMEPLAY REMAINS ACTIVE ============")
